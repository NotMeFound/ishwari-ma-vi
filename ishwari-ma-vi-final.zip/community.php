<?php
declare(strict_types=1);
require_once __DIR__ . '/main.php';
\App\AppKernel::run('community');
